from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Avg, Count
from .models import Restaurant, Cuisine, Review
from .forms import ReviewForm
from django.conf import settings
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.core.serializers import serialize
import requests
from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .models import Restaurant, Cuisine
from django.conf import settings

class HomeView(ListView):
    model = Restaurant
    template_name = 'home.html'
    context_object_name = 'restaurants'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['google_maps_api_key'] = settings.GOOGLE_MAPS_API_KEY
        return context

class RestaurantDetailView(DetailView):
    model = Restaurant
    template_name = 'restaurant_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['review_form'] = ReviewForm()
        context['google_maps_api_key'] = settings.GOOGLE_MAPS_API_KEY
        context['google_reviews'] = fetch_google_reviews(self.object.name, self.object.address)  # Fetch Google reviews
        return context

def cuisine_list(request):
    cuisines = Cuisine.objects.all()
    context = {
        'cuisines': cuisines,
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY
    }
    return render(request, 'cuisine_list.html', context)

def restaurant_by_cuisine(request, cuisine_id):
    cuisine = get_object_or_404(Cuisine, pk=cuisine_id)
    restaurants = Restaurant.objects.filter(cuisine=cuisine)
    return render(request, 'restaurant_by_cuisine.html', {'cuisine': cuisine, 'restaurants': restaurants})

@login_required
def add_review(request, pk):
    restaurant = get_object_or_404(Restaurant, pk=pk)
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.restaurant = restaurant
            review.user = request.user
            review.save()
    return redirect('restaurant_detail', pk=pk)

@login_required
def toggle_favorite(request, pk):
    restaurant = get_object_or_404(Restaurant, pk=pk)
    user = request.user
    if restaurant in user.favorite_restaurants.all():
        user.favorite_restaurants.remove(restaurant)
    else:
        user.favorite_restaurants.add(restaurant)
    return redirect('restaurant_detail', pk=pk)

def search_results(request):
    query = request.GET.get('q')
    cuisine_id = request.GET.get('cuisine')
    latitude = request.GET.get('latitude')
    longitude = request.GET.get('longitude')
    
    print(f"Query: {query}, Cuisine ID: {cuisine_id}, Latitude: {latitude}, Longitude: {longitude}")


    restaurants = Restaurant.objects.all()

    # Filter restaurants based on query and cuisine
    if query:
        restaurants = restaurants.filter(Q(name__icontains=query) | Q(cuisine__name__icontains=query))

    if cuisine_id:
        restaurants = restaurants.filter(cuisine_id=cuisine_id)
        
    print(f"Number of restaurants found: {restaurants.count()}")

    # If latitude and longitude are provided, use Google Maps API to filter by distance
    if latitude and longitude:
        google_api_key = settings.GOOGLE_MAPS_API_KEY
        user_location = f"{latitude},{longitude}"

        # Use Distance Matrix API to get distances to each restaurant
        for restaurant in restaurants:
            restaurant_location = f"{restaurant.latitude},{restaurant.longitude}"
            distance = get_distance_from_google_maps(user_location, restaurant_location, google_api_key)
            restaurant.distance = distance  # Attach the distance attribute to each restaurant object

        # Sort restaurants by distance
        restaurants = sorted(restaurants, key=lambda x: x.distance)

    context = {
        'restaurants': restaurants,
        'query': query,
        'selected_cuisine': cuisine_id,
    }
    return render(request, 'search_results.html', context)

def get_distance_from_google_maps(user_location, restaurant_location, api_key):
    """Helper function to get distance from Google Maps Distance Matrix API."""
    url = 'https://maps.googleapis.com/maps/api/distancematrix/json'
    params = {
        'origins': user_location,
        'destinations': restaurant_location,
        'key': api_key,
        'units': 'metric',
    }

    response = requests.get(url, params=params)
    print(f"Google Maps API Response: {response.json()}")
    if response.status_code == 200:
        results = response.json()
        if results['rows']:
            distance_info = results['rows'][0]['elements'][0]['distance']
            if 'value' in distance_info:
                return distance_info['value'] / 1000  # Convert meters to kilometers
    return None

def restaurant_list(request):
    restaurants = Restaurant.objects.all()
    cuisines = Cuisine.objects.all()
    
    # Serialize restaurant data to JSON for use in JavaScript
    restaurant_data = serialize('json', restaurants, fields=('id', 'name', 'latitude', 'longitude'))

    context = {
        'restaurants': restaurant_data,
        'cuisines': cuisines,
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY,
    }
    return render(request, 'restaurant_list.html', context)

def fetch_google_reviews(restaurant_name, restaurant_address):
    google_places_url = 'https://maps.googleapis.com/maps/api/place/findplacefromtext/json'
    params = {
        'input': f'{restaurant_name} {restaurant_address}',
        'inputtype': 'textquery',
        'fields': 'place_id',
        'key': settings.GOOGLE_MAPS_API_KEY,
    }

    response = requests.get(google_places_url, params=params)
    if response.status_code == 200 and response.json().get('candidates'):
        place_id = response.json()['candidates'][0]['place_id']
        
        # Fetch details including reviews
        details_url = f'https://maps.googleapis.com/maps/api/place/details/json'
        details_params = {
            'place_id': place_id,
            'fields': 'reviews',
            'key': settings.GOOGLE_MAPS_API_KEY,
        }
        details_response = requests.get(details_url, params=details_params)
        if details_response.status_code == 200:
            return details_response.json().get('result', {}).get('reviews', [])
    return []

def restaurant_detail(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, id=restaurant_id)
    reviews = restaurant.reviews.all().order_by('-created_at')
    google_reviews = fetch_google_reviews(restaurant.name, restaurant.address)  # Optional: Fetch Google reviews

    context = {
        'restaurant': restaurant,
        'reviews': reviews,
        'google_reviews': google_reviews,  # Include Google reviews if implemented
        'review_form': ReviewForm(),
    }
    return render(request, 'restaurant_detail.html', context)

def restaurant_api(request):
    """API endpoint to get all restaurant data in JSON format."""
    restaurants = Restaurant.objects.all()
    data = [{
        'id': restaurant.id,
        'name': restaurant.name,
        'latitude': restaurant.latitude,
        'longitude': restaurant.longitude,
        'rating': restaurant.rating,
        'cuisine': restaurant.cuisine.name if restaurant.cuisine else ''
    } for restaurant in restaurants]
    return JsonResponse(data, safe=False)

def home(request):
    """Home view to display all restaurants and cuisines."""
    restaurants = Restaurant.objects.all()
    cuisines = Cuisine.objects.all()
    context = {
        'restaurants': restaurants,
        'cuisines': cuisines,
        'google_maps_api_key': settings.GOOGLE_MAPS_API_KEY,
    }
    return render(request, 'home.html', context)
